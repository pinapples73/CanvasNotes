package techStaff;

import staff.Employee;

public class Developer extends Employee {

    public Developer(String name, String niNumber, double salary) {
        super(name, niNumber, salary);
    }
}
