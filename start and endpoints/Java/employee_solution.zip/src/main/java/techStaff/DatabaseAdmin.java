package techStaff;

import staff.Employee;

public class DatabaseAdmin extends Employee {

    public DatabaseAdmin(String name, String niNumber, double salary) {
        super(name, niNumber, salary);
    }
}
