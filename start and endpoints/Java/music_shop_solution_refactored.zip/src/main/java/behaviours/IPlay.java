package behaviours;

public interface IPlay {
    String play();
}
