package behaviours;

public interface ISell {
    int calculateMarkup();
}
