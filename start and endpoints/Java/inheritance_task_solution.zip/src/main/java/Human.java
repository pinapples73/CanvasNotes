public class Human extends Mammal {
    public String walk(){
        return "What a lovely day for a stroll, pip pip old boy!";
    }
}