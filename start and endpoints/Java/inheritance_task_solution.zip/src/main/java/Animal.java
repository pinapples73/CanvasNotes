public class Animal {
    public String eat(){
        return "Mmmmm!";
    }

    public String breathe(){
        return "Huff, puff";
    }
}