public class Mammal extends Animal {
    public String talk(){
        return "Hello there!";
    }
}