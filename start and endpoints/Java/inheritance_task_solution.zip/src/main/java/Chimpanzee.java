public class Chimpanzee extends Mammal {
    public String walk(){
        return "I wanna walk like you!";
    }

}