package healer;

import players.Player;

public interface IHeal {

    void heal(Player player);
}
