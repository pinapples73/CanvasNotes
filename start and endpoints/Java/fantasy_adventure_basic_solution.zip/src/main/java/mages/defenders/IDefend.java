package mages.defenders;

import enemies.Enemy;

public interface IDefend {

    void defend(Enemy enemy);
}
