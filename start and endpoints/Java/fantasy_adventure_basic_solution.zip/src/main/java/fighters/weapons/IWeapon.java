package fighters.weapons;

import enemies.Enemy;

public interface IWeapon {

    void attack(Enemy enemy);
}
