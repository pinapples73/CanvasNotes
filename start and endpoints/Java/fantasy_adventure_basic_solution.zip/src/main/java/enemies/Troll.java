package enemies;

public class Troll extends Enemy {

    public Troll(int healthValue){
        super(healthValue);
    }
}
