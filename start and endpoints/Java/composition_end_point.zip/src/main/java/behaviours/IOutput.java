package behaviours;

public interface IOutput {
    String outputData(String data);
}
