public enum AirportName {
    EDI, GLA
}
