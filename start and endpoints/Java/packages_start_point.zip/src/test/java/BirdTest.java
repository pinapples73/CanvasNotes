// import animal.air.Bird;
// import org.junit.Before;
// import org.junit.Test;
//
// import static org.junit.Assert.assertEquals;
//
// public class BirdTest {
//
//     Bird bird;
//
//     @Before
//     public void before(){
//         bird = new Bird();
//     }
//
//     @Test
//     public void canSpeak() {
//         assertEquals("Tweet Tweet", bird.speak());
//     }
// }
