package human;


import animal.Dog;


public class Trainer {
    public String teach(Dog dog) {
        return dog.bark();
    }
}
