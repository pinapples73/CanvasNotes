package attractions;

public class Playground extends Attraction {

    public Playground(String name, int rating) {
        super(name, rating);
    }
}
