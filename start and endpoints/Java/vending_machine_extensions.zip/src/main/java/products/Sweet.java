package products;

public class Sweet extends Product {

    public Sweet(String name) {
        super(name);
    }
}
