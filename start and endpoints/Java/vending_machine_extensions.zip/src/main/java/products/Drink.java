package products;

public class Drink extends Product {

    public Drink(String name) {
        super(name);
    }
}
