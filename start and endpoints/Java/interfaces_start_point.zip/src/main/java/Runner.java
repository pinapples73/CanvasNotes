public class Runner extends Athlete {


}
