package behaviours;

public interface ISell {
}
