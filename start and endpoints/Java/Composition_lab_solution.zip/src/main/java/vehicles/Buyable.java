package vehicles;

import people.Customer;

public interface Buyable {

    public boolean canBuy(Customer customer);
}
