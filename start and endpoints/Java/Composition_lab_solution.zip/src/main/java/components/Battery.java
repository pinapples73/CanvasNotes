package components;

public class Battery {

    private int range;

    public Battery(int range) {
        this.range = range;
    }

    public int getRange() {
        return range;
    }
}
