package components;

public class FuelTank {

    private double tankCapacity;

    public FuelTank(double tankCapacity) {
        this.tankCapacity = tankCapacity;
    }

    public double getTankCapacity() {
        return tankCapacity;
    }
}
