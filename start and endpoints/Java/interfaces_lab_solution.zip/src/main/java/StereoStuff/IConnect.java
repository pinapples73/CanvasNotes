package StereoStuff;

public interface IConnect {
    String connect(Stereo stereo);
}
