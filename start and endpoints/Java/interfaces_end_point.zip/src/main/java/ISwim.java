public interface ISwim {
    public void swim(int distance);

}
