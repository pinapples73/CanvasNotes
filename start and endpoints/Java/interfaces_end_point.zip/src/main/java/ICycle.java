public interface ICycle {
    public void cycle(int distance);
}
