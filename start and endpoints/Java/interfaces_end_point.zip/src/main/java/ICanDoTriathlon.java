public interface ICanDoTriathlon extends IRun, ISwim, ICycle{
}
