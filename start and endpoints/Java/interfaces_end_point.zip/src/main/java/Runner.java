public class Runner extends Athlete implements IRun {

    public void run(int distance){
        distanceTravelled += distance;
    }
}
