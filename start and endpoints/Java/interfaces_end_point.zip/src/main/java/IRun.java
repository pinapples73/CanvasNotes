public interface IRun {
    public void run(int distance);
}
