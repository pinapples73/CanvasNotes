public interface ICanDoHurdles extends IRun {
    public void jump();
}
