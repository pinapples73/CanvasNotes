package stalls;

public enum ParkingSpot {
    A1,
    A2,
    A3,
    A4,
    B1,
    B2,
    B3,
    B4
}
