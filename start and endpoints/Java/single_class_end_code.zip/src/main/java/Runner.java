public class Runner {

    public static void main(String[] args){
        Bear bear = new Bear("Balu");
        bear.setName("Baloo");
        System.out.println(bear.getName());
    }
}
