package music_shop;

public enum InstrumentType {
    STRING,
    WIND,
    BRASS,
    PERCUSSION,
    KEYBOARD
}
