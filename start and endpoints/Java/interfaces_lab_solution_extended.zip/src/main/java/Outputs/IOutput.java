package Outputs;

public interface IOutput {
    public String blastSound(String sound);
}
