package Components;

public interface IPlay {
    String play(String title);
}
