public enum Suit {
    HEARTS,
    DIAMONDS,
    SPADES,
    CLUBS
}
