package machine.components;

public enum Code {
    A1,
    A2,
    A3
}
