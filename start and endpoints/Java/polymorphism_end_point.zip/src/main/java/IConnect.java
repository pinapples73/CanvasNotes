public interface IConnect {
    public String connect(String data);
}
