package treasure;

import java.util.Random;

public interface ITreasure {

     int getValue();

}
