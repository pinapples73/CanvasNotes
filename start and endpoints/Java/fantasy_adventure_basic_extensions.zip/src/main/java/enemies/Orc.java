package enemies;

public class Orc extends Enemy {

    public Orc(int healthValue){
        super(healthValue);
    }
}
